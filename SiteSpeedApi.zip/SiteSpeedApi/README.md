# Site Speed API

<br>

## Site Speed API

<br>

### 📜 Technology used

- WordPress hooks
- API extension
- PHP
